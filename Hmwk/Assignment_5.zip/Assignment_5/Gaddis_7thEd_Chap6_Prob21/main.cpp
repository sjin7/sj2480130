/* 
 * File:   main.cpp
 * Author: Shaney
 *
 * Created on July 23, 2014, 11:42 PM
 */

#include <cstdlib>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    return 0;
}

