/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on July 2, 2014, 11:30 AM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    const char MSIZE = 10;
    char month1[MSIZE],  month2[MSIZE],  month3[MSIZE];
    
    cout << "Input the 3 months: ";
    cin >> month1 >> month2 >> month3;
    
    cout << "To be continued." << endl;
    
    return 0;
}

