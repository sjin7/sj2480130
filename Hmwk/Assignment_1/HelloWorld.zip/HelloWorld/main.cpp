/* 
 * File:   HelloWorld
 * Author: Shen Jin
 * Created on June 23, 2014, 11:33 PM
 */

#include <iostream>

using namespace std;

//User Defined Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {

    //Output Simple Text
    cout << "Hello World" << endl;
    //Exit Stage Right
    return 0;
}

