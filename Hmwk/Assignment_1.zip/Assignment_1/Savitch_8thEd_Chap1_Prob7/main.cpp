/* 
 * File: Savitch_8th_Chap1_Prob7
 * Author: Shen Jin
 * Created on June 25, 2014, 2:31 PM
 */

//System Libraries
#include <iostream>

using namespace std;

//User Defined Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {

    for (int i=0; i<55; i++)
    {
        cout << "*";
    }
    cout << endl;
   
    cout << "        C C C                  S S S S           !!\n";
    cout << "      C       C              S         S         !!\n";
    cout << "     C                      S                    !!\n";
    cout << "    C                        S                   !!\n";
    cout << "    C                          S S S             !!\n";
    cout << "    C                                 S          !!\n";
    cout << "     C                                 S         !!\n";
    cout << "      C        C             S        S            \n";
    cout << "        C C C                  S S S S           00\n";
            
    for (int i=0; i<55; i++)
    {
        cout << "*";
    }
    cout << endl;
    
    cout << "    Computer Science is Cool Stuff!!!" << endl;
    
    return 0;
}

