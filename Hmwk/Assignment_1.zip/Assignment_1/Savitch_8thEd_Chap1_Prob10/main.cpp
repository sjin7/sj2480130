/* 
 * File: Savitch_8thEd_Chap1_Prob10
 * Author: Shen Jin
 * Created on June 25, 2014, 11:09 PM
 */

//System Libraries
#include <iostream>

using namespace std;

//User Defined Libraries

//Global Constants

// Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {

    char Lt;
    
    cout << "Type in a letter.\n";
    cout << "Letter: ";
    cin >> Lt;
    cout << "    " << Lt << " " << Lt << " " << Lt << endl;
    cout << "   " << Lt << "     " << Lt << endl;
    cout << "  " << Lt << endl;
    cout << "  " << Lt << endl;
    cout << "  " << Lt << endl;
    cout << "  " << Lt << endl;
    cout << "  " << Lt << endl;
    cout << "   " << Lt << "     " << Lt << endl;
    cout << "    " << Lt << " " << Lt << " " << Lt << endl;
    
    return 0;
}

